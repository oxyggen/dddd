// import { PROGRAMS } from "../actionTypes";

export default (state = {}, action) => {
    // if (action.type === actionType.FETCH_BLOG) {
    //     return {state, ...action.payload};
    // }
    return state;
}
