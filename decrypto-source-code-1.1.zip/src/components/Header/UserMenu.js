import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

import { routes } from '../../shared/constants';

// import LogoutLink from '../LogoutLink';

const texts = {
  myAccount: 'My Account',
};

const UserMenu = ({ user }) => {
  
  return (
    <div>
      Logout
    </div>
  );
};

/* UserMenu.propTypes = {
//   user: PropTypes.ob
 };
*/

export default UserMenu;
