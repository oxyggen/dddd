export function mapStateToProps(state) {
  return {
      // assets: state.assets.list,
      // coinsData: state.landing.coinsData,
      // coinsBonusRegisterData: state.landing.coinsBonusRegisterData,
    }
}
