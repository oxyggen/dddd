import { connect } from 'react-redux';

import Footer from "./Footer";

// const mapStateToProps = state => {
//     return {
//         user: state.userAction.user || null,
//     }
// }

export default Footer;
