import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

// import { routes } from '../../shared/constants';

const Footer = () => {
    
    return (
        <div>
            Footer
        </div>
    );
}

Footer.propTypes = {};

export default Footer;
